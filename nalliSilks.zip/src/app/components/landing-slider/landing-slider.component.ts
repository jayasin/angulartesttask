import { Component, OnInit } from '@angular/core';

import SwiperCore, {
  Navigation,
  Pagination
} from 'swiper/core';

SwiperCore.use([Navigation, Pagination]);

@Component({
  selector: 'app-landing-slider',
  templateUrl: './landing-slider.component.html',
  styleUrls: ['./landing-slider.component.scss']
})
export class LandingSliderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  onSwiper(swiper) {
    console.log(swiper);
  }
  onSlideChange() {
    console.log('slide change');
  }

}
